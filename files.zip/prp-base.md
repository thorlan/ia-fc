# PRP: [Nome da Feature]

> Gerado a partir de `docs/features/NNN-nome-da-feature.md`.
> Prompt sugerido para gerar este arquivo com a IA:
> "Leia o documento de feature em docs/features/NNN-nome-da-feature.md, o contexto-produto.md, contexto-tecnico.md, guidelines (.github/copilot-instructions.md) e os ADRs relevantes. Pesquise no codebase padrões e exemplos similares. Gere um PRP completo neste template, preenchendo todas as seções com precisão."

## Goal (Objetivo)

[O que deve ser entregue, de forma objetiva e verificável.]

## Why (Por quê)

- [Motivo de negócio/técnico 1]
- [Motivo de negócio/técnico 2]

## What (O quê)

[Descrição funcional detalhada do comportamento esperado.]

### Success Criteria (Critérios de sucesso)

- [ ] [Critério 1 — testável]
- [ ] [Critério 2 — testável]

## All Needed Context (Contexto necessário)

### Documentação e referências

| Tipo | Local | Por quê |
|---|---|---|
| file | `[caminho]` | [motivo de ser relevante] |
| doc | `docs/libs/[LIB].md` | [motivo] |
| url | `[link]` | [motivo] |
| adr | `docs/adrs/[NNN].md` | [motivo] |

### Library quirks / Anti-patterns / Non-gotchas

> Armadilhas conhecidas que a IA deve evitar nesta implementação.

- **CRITICAL:** [regra que não pode ser quebrada]
- **CRITICAL:** [regra que não pode ser quebrada]

## Tree atual → Tree futura

```
# Tree atual (relevante ao escopo)
src/
├── ...

# Tree futura esperada
src/
├── ...   # [novo/alterado/removido]
```

## Implementation Blueprint (Plano de implementação)

### Modelo de dados (se aplicável)

[Estruturas, entidades, schemas envolvidos.]

### Lista de tarefas (ordem de execução)

1. [Tarefa 1]
2. [Tarefa 2]
3. [Tarefa 3]

### Pseudocódigo / pontos de integração

```
[pseudocódigo ou descrição de como as peças se conectam]
```

## Validation Loop (Loop de validação)

### Nível 1 — Sintaxe & Estilo

```bash
[comando de lint/format]
```

### Nível 2 — Testes unitários

```bash
[comando de testes]
```

### Nível 3 — Validação funcional/integração

```bash
[comando ou passo manual de verificação]
```

## Quality / Confidence Score

**Score:** [1-10]
**Riscos/incertezas identificados:** [liste o que ficou menos claro na geração deste PRP]

---
> ⚠️ Revisão humana obrigatória antes de executar: confira se os arquivos citados existem, se o plano faz sentido e se os critérios de sucesso são realmente testáveis.
