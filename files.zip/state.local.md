# State Local do Projeto

> Atualize este arquivo ao final de cada sessão de trabalho com IA. Ele existe para que um novo chat (= "novo desenvolvedor contratado") entenda rapidamente onde o desenvolvimento parou, sem depender do histórico da conversa anterior.

**Última atualização:** [AAAA-MM-DD]

## Onde o projeto está agora

[Resumo em 2-3 frases do estado atual.]

## Features/tarefas concluídas recentemente

- [x] [Tarefa/feature] — [data]
- [x] [Tarefa/feature] — [data]

## Em andamento

- [ ] [Tarefa atual] — [o que já foi feito, o que falta, qual PRP/arquivo de tarefa referencia]

## Próximos passos planejados

- [Próximo item do plano de ação]

## Bloqueios / pendências

- [Algo que está travando o progresso, decisão pendente, dependência externa]

## Notas importantes para retomar o contexto

[Qualquer detalhe que não esteja óbvio nos outros documentos, mas que seja crítico para continuar de onde parou.]
