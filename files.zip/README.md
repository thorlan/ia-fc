# [Nome do Projeto]

[Breve descrição de uma linha sobre o que o projeto faz.]

## Como rodar o projeto

### Pré-requisitos

- [ex: Node.js 20+]
- [ex: Docker]

### Variáveis de ambiente

Copie `.env.example` para `.env` e preencha:

```
[VARIAVEL_1]=[descrição do que é]
[VARIAVEL_2]=[descrição do que é]
```

### Instalação

```bash
[comando de instalação]
```

### Rodando localmente

```bash
[comando para subir o projeto]
```

### Rodando os testes

```bash
[comando de testes]
```

## Documentação do projeto

> Índice central. Sempre que criar um novo doc de contexto, adicione o link aqui.

- 📄 [Contexto de Produto](docs/contexto-produto.md)
- ⚙️ [Contexto Técnico](docs/contexto-tecnico.md)
- 📚 [Documentação das Libs](docs/libs/)
- 🧭 [ADRs (decisões de arquitetura)](docs/adrs/)
- 🗺️ [Plano de Ação](docs/plano-de-acao.md)
- ✅ [Tarefas](docs/tarefas/)
- 🤖 [Guidelines para IA](.github/copilot-instructions.md)

## Estrutura de pastas

```
src/
docs/
├── contexto-produto.md
├── contexto-tecnico.md
├── libs/
├── adrs/
├── plano-de-acao.md
├── tarefas/
└── features/
```
