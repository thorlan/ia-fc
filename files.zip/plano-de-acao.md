# Plano de Ação

> Visão de alto nível do que será desenvolvido. Cada fase pode gerar uma ou mais tarefas detalhadas em `docs/tarefas/`.

## Objetivo geral

[O que se espera alcançar com este ciclo de desenvolvimento? Ex: lançar MVP de X, migrar Y para Z.]

## Fases

### Fase 1 — [Nome da fase]

- **Objetivo:** [o que essa fase entrega]
- **Status:** [Não iniciado / Em andamento / Concluído]
- **Tarefas relacionadas:** [link para docs/tarefas/xxx.md]

### Fase 2 — [Nome da fase]

- **Objetivo:**
- **Status:**
- **Tarefas relacionadas:**

### Fase 3 — [Nome da fase]

- **Objetivo:**
- **Status:**
- **Tarefas relacionadas:**

## Fora do escopo deste plano

[O que não será feito neste ciclo, para alinhar expectativas com a IA e com o time.]

## Riscos conhecidos

- [Risco 1 e como mitigar]
- [Risco 2 e como mitigar]
