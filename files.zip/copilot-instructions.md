# Guidelines do Projeto para IA

> Este arquivo é lido automaticamente pelo GitHub Copilot Chat no VS Code.
> Coloque aqui regras que a IA deve SEMPRE seguir, em qualquer tarefa.

## Idioma

- Instruções e documentação: [ex: português]
- Código e comentários no código: [ex: inglês]

## Padrões de código

- Estilo de formatação: [ex: Prettier, Black, gofmt — citar config se houver]
- Convenção de nomenclatura: [ex: camelCase para variáveis, PascalCase para classes]
- Linter usado: [ex: ESLint com regras X]

## Documentação de código

- [ex: Toda função pública deve ter um comentário de doc acima explicando parâmetros e retorno]
- [ex: Componentes React devem ter um bloco de descrição no topo do arquivo]

## Testes

- Framework de testes: [ex: Jest, Pytest]
- Cobertura mínima esperada: [ex: 80%]
- Convenção de nomenclatura dos arquivos de teste: [ex: *.spec.ts]
- Rodar testes com: `[comando]`

## Padrões de commit / PR

- Convenção de commit: [ex: Conventional Commits]
- Tamanho esperado de PRs: [ex: PRs pequenos e focados em uma única mudança]

## Coisas que a IA NUNCA deve fazer neste projeto

- [ex: Nunca instalar uma nova lib sem antes checar o ADR correspondente]
- [ex: Nunca alterar arquivos da pasta /legacy sem aviso explícito]
- [ex: Nunca remover testes existentes para "fazer passar" o build]

## Comandos úteis do projeto

| Ação | Comando |
|---|---|
| Rodar localmente | `[comando]` |
| Rodar testes | `[comando]` |
| Rodar lint | `[comando]` |
| Build | `[comando]` |
