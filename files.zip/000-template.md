# ADR 000: [Título curto da decisão]

> Copie este arquivo para `NNN-titulo-da-decisao.md` (numeração sequencial) para cada nova decisão.

**Status:** [Proposto / Aceito / Substituído por ADR-XXX]
**Data:** [AAAA-MM-DD]

## Contexto

[Qual problema ou necessidade levou a essa decisão? Que restrições existiam?]

## Decisão

[O que foi escolhido? Seja específico: nome da lib/ferramenta/padrão, versão se relevante.]

## Onde é usado

[Em qual parte do sistema essa decisão se aplica? Ex: camada de persistência, autenticação, fila de mensagens.]

## Motivo

[Por que essa opção e não outra? Quais critérios pesaram mais: performance, custo, familiaridade do time, comunidade, etc.]

## Alternativas consideradas

| Alternativa | Motivo da rejeição |
|---|---|
| [opção A] | [motivo] |
| [opção B] | [motivo] |

## Consequências

- **Positivas:** [ganhos esperados]
- **Negativas / trade-offs:** [o que se perde ou o risco assumido]

## Observação para a IA

> Esta decisão é vinculante: não sugerir ferramentas/libs alternativas para este mesmo escopo sem antes revisar este ADR com o time.
