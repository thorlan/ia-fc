# Contexto Técnico

> Preencha descrevendo a visão técnica geral do projeto: stack, arquitetura, metodologias. Isso dá à IA o "mapa" do sistema antes de tocar em qualquer código.

## Stack principal

- **Linguagem(ns):** [ex: TypeScript, Python]
- **Framework(s):** [ex: NestJS, Django, Next.js]
- **Banco de dados:** [ex: PostgreSQL, MongoDB]
- **Infraestrutura:** [ex: AWS, Docker, Kubernetes]
- **Outras ferramentas relevantes:** [ex: filas, cache, CI/CD]

## Arquitetura em alto nível

[Descreva: monolito, microserviços, MVC, arquitetura hexagonal, event-driven, etc. Se possível, inclua um diagrama simples ou link para um.]

## Organização de pastas

```
src/
├── [pasta]/     # [o que fica aqui]
├── [pasta]/     # [o que fica aqui]
└── [pasta]/     # [o que fica aqui]
```

## Metodologias e práticas adotadas

- [ ] TDD (Test-Driven Development)
- [ ] Trunk-based development
- [ ] Code review obrigatório
- [ ] CI/CD com pipeline de [nome]
- [Outras práticas específicas do time]

## Ambientes

| Ambiente | URL / acesso | Observações |
|---|---|---|
| Local | | |
| Staging | | |
| Produção | | |

## Pontos de atenção / limitações conhecidas

[Débitos técnicos, partes do sistema mais frágeis, áreas que exigem cuidado extra.]
