# Contexto de Produto

> Preencha este documento descrevendo do que o projeto se trata, do ponto de vista de produto/negócio. Isso ajuda a IA (e novos desenvolvedores) a entender o "porquê" por trás das features.

## O que é o projeto

[Descreva em 2-3 frases o que o projeto faz e para quem ele é.]

## Problema que resolve

[Qual dor/necessidade este produto resolve? Para qual público?]

## Principais funcionalidades

- [Funcionalidade 1 — breve descrição]
- [Funcionalidade 2 — breve descrição]
- [Funcionalidade 3 — breve descrição]

## Usuários / Personas

- **[Nome da persona]**: [o que ela faz no sistema, principais objetivos]

## Regras de negócio importantes

> Liste aqui regras que a IA precisa sempre respeitar ao gerar código, mesmo que não estejam explícitas em cada tarefa.

- [Regra 1]
- [Regra 2]

## Fora de escopo

[O que o produto explicitamente NÃO faz, para evitar que a IA sugira features fora do contexto.]

## Glossário

> Termos específicos do domínio do negócio que podem confundir se não explicados.

| Termo | Significado |
|---|---|
| [termo] | [definição] |
