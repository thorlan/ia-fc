# Tarefa: [Nome da tarefa]

> Copie este arquivo para `NNN-nome-da-tarefa.md` para cada nova tarefa. Faz parte de uma fase do Plano de Ação.

**Fase relacionada:** [link para docs/plano-de-acao.md#fase-x]
**Status:** [Não iniciado / Em andamento / Concluído]

## Descrição

[O que precisa ser feito, em linguagem simples.]

## TODO List

- [ ] [Passo 1]
- [ ] [Passo 2]
- [ ] [Passo 3]
- [ ] Escrever/atualizar testes
- [ ] Rodar lint e testes
- [ ] Atualizar documentação relevante (README, ADR se aplicável)

## Arquivos provavelmente afetados

- `[caminho/arquivo1]`
- `[caminho/arquivo2]`

## Critérios de aceite

- [ ] [Critério verificável 1]
- [ ] [Critério verificável 2]

## Observações

[Qualquer cautela, dependência de outra tarefa, ou contexto adicional.]
