# Feature: [Nome da feature]

> Copie para `NNN-nome-da-feature.md`. Este é o documento de entrada que a IA vai ler para gerar o PRP. Quanto mais preciso, melhor o PRP gerado — vagueza aqui vira vagueza no PRP.

## Contexto

[Por que essa feature é necessária agora? Qual problema ela resolve?]

## Objetivo (o quê)

[Descrição clara e objetiva do que deve ser construído/alterado.]

## Exemplos

> Referencie arquivos ou trechos de código já existentes no projeto que sirvam de padrão/exemplo para esta feature.

- `[caminho/arquivo-exemplo.ts]` — [por que é relevante como referência]

## Documentação relevante

- [Link ou arquivo de docs/libs relevante]
- [ADR relacionado, se houver]

## Critérios de sucesso

- [ ] [Critério verificável 1]
- [ ] [Critério verificável 2]

## Observações e cautelas

- [ex: Este contexto pode estar desatualizado — validar com o time antes de assumir]
- [ex: Não alterar X sem checar ADR-00Y]
- [Riscos, dependências de outras tarefas, restrições conhecidas]
