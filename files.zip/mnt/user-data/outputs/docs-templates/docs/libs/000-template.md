# [NOME-DA-LIB]

> Copie para `NOME-DA-LIB.md` (ex: LANGCHAIN.md). Pode ser gerado com apoio da IA via Context7, documentação oficial, ou clonando o repositório da lib.

**Versão usada no projeto:** [x.y.z]
**Onde é usada:** [ex: camada de integração com IA, autenticação, etc.]

## Prompt sugerido para gerar este arquivo com IA

> "Analise o codebase (pasta src e arquivo de dependências), identifique as bibliotecas de terceiros usadas. Para a lib [NOME], consulte o Context7 MCP (ou a documentação oficial / repositório clonado) e preencha este arquivo com: propósito, API principal usada no projeto, peculiaridades e anti-patterns."

## Propósito no projeto

[Por que essa lib foi escolhida / para que ela é usada aqui.]

## API / funções principais usadas

- `[função/método]` — [para que serve]
- `[função/método]` — [para que serve]

## Peculiaridades (library quirks)

[Comportamentos não óbvios que a lib tem e que a IA precisa saber.]

## Anti-patterns / Non-gotchas

> Coisas que parecem certas mas dão problema neste projeto específico.

- [Anti-pattern 1]
- [Anti-pattern 2]

## Links de referência

- Documentação oficial: [url]
- ADR relacionado (se houver): [link]
